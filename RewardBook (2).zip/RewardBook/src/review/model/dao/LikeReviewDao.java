package review.model.dao;

public class LikeReviewDao {

}
