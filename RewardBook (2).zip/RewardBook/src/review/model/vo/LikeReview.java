package review.model.vo;

public class LikeReview {

}
