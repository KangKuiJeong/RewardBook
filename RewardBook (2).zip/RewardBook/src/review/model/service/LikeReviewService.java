package review.model.service;

public class LikeReviewService {

}
