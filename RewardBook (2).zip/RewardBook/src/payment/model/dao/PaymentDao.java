package payment.model.dao;

import java.sql.Connection;
import java.util.ArrayList;

import payment.model.vo.Payment;

public class PaymentDao {

	public int deletePayment(Connection conn, String p_no) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int insertPayment(Connection conn, String p_no) {
		// TODO Auto-generated method stub
		return 0;
	}

	public ArrayList<Payment> listPayment(Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}

	public int updatePayment(Connection conn, String p_no) {
		// TODO Auto-generated method stub
		return 0;
	}

}
