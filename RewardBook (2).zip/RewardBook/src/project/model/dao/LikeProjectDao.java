package project.model.dao;

import java.sql.Connection;
import java.util.ArrayList;

import project.model.vo.LikeProject;

public class LikeProjectDao {

	public int deleteLikeProject(Connection conn, String m_no) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int insertLikeProject(Connection conn, String m_no) {
		// TODO Auto-generated method stub
		return 0;
	}

	public ArrayList<LikeProject> listLikeProject(Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}

}
