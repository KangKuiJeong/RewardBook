package Stats.model.dao;

import java.sql.Connection;

public class StatsDao {

	public int insertVisit(Connection conn, java.sql.Date date, int count) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int updateVisit(Connection conn, int count) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
