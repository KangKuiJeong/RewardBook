package project.model.dao;

import java.sql.Connection;
import java.util.ArrayList;

import project.model.vo.ProjectNews;

public class ProjectNewsDao {

	public int deleteProjectNews(Connection conn, String pn_no) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int insertProjectNews(Connection conn, String pn_no) {
		// TODO Auto-generated method stub
		return 0;
	}

	public ProjectNews selectProjectNews(String pn_no) {
		// TODO Auto-generated method stub
		return null;
	}

	public ArrayList<ProjectNews> listProjectNews(Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}

	public int updateProjectNews(Connection conn, String pn_no) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
