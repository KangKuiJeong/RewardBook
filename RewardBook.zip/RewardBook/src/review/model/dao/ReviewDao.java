package review.model.dao;

import java.sql.Connection;
import java.util.ArrayList;

import review.model.vo.Review;

public class ReviewDao {

	public int deleteReview(Connection conn, String rv_no) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int insertReview(Connection conn, String rv_no) {
		// TODO Auto-generated method stub
		return 0;
	}

	public ArrayList<Review> listReview(Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}

	public int updateReview(Connection conn, String rv_no) {
		// TODO Auto-generated method stub
		return 0;
	}

	
}
