package review.model.vo;

public class ReviewReply {

}
