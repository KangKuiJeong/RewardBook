package review.model.vo;

public class Review {

}
